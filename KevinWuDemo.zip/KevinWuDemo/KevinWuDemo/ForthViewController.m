//
//  ForthViewController.m
//  KevinWuDemo
//
//  Created by KevinWu on 2018/10/18.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import "ForthViewController.h"
#import "SecondViewController.h"
#import "Masonry.h"
#import "UINavigationController+WCQFullScreenPopGesture.h"
@interface ForthViewController ()

@end

@implementation ForthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"ForthViewController";
    self.view.backgroundColor = [UIColor lightGrayColor];
    self.wcq_hideNavigationBar = YES;
    // Do any additional setup after loading the view.
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"点我试试" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(didPressGotoNextPage:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(44);
        make.bottom.equalTo(self.view.mas_bottomMargin).offset(-20);
        make.left.right.equalTo(button.superview).insets(UIEdgeInsetsMake(0, 12, 0 , 12));
    }];
    
    CAGradientLayer *gradientLayer = [CAGradientLayer new];
    gradientLayer.colors = @[(id)[UIColor redColor].CGColor,(id)[UIColor greenColor].CGColor,(id)[UIColor blueColor].CGColor];
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(1, 0);
    [button.layer addSublayer:gradientLayer];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        gradientLayer.frame = button.bounds;
    });
}

- (void)didPressGotoNextPage:(id)sender {
    [self.navigationController pushViewController:SecondViewController.new animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSLog(@"viewWillAppear");
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
