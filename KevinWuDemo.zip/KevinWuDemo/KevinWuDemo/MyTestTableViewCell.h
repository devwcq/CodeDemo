//
//  MyTestTableViewCell.h
//  KevinWuDemo
//
//  Created by KevinWu on 2018/10/18.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTestTableViewCell : UITableViewCell

@end
