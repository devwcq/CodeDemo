//
//  UIView+ResponserChain.m
//  KevinWuDemo
//
//  Created by KevinWu on 2018/9/6.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import "UIView+ResponserChain.h"

@implementation UIView (ResponserChain)
//- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
//    UIView *hitView = nil;
//    if (!self.userInteractionEnabled || self.hidden || self.alpha <= 0) {
//        hitView = nil;
//    }else {
//        if (CGRectContainsPoint(self.bounds, point)) {
//            for (UIView *subView in [self.subviews reverseObjectEnumerator]) {
//                CGPoint subPoint = [subView convertPoint:point toView:self];
//                CGPoint subPoint1 = [self convertPoint:point fromView:subView];
//                UIView *hitTestView = [subView hitTest:subPoint withEvent:event];
//                if (hitTestView) {
//                    hitView = hitTestView;
//                    break;
//                }
//            }
//        }
//        else {
//            hitView = nil;
//        }
//    }
//    return hitView;
//}
@end
