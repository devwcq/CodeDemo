//
//  SecondViewController.m
//  KevinWuDemo
//
//  Created by KevinWu on 2018/10/9.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import "Masonry.h"
#import "SecondViewController.h"
#import "UINavigationController+WCQFullScreenPopGesture.h"
#import "ThirdViewController.h"
#import "ViewController.h"
#import "MyTestTableViewCell.h"
//#import "UINavigationController+FDFullscreenPopGesture.h"



@interface SecondViewController ()
<
UITableViewDelegate,
UITableViewDataSource
>
@end

@implementation SecondViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];

    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:({
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitle:@"返回" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        button.frame = CGRectMake(0, 0, 50, 40);
        [button addTarget:self action:@selector(didPressBackLastPage:) forControlEvents:UIControlEventTouchUpInside];
        button;
    })];
    
    
//    self.wcq_hideNavigationBar = YES;
//    self.wcq_disablePopGesture = YES;
    
    self.view.backgroundColor = [UIColor redColor];
    UITableView *table;
    [self.view addSubview:({
        table = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        table.delegate = self;
        table.dataSource = self;
        [table registerNib:[UINib nibWithNibName:NSStringFromClass([MyTestTableViewCell class]) bundle:nil] forCellReuseIdentifier:NSStringFromClass([MyTestTableViewCell class])];
        table.tableFooterView = ({
            UIView *view = [UIView new];
            view;
        });
        table.rowHeight = 80.f;
        table.sectionFooterHeight = CGFLOAT_MIN;
        table.sectionHeaderHeight = CGFLOAT_MIN;
        table.tag = 2222;
        table;
    })];
    
    [table mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"点我试试" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(didPressGotoNextPage:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(44);
        make.bottom.equalTo(self.view.mas_bottomMargin).offset(-20);
        make.left.right.equalTo(button.superview).insets(UIEdgeInsetsMake(0, 12, 0 , 12));
    }];
    
    CAGradientLayer *gradientLayer = [CAGradientLayer new];
    gradientLayer.colors = @[(id)[UIColor redColor].CGColor,(id)[UIColor greenColor].CGColor,(id)[UIColor blueColor].CGColor];
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(1, 0);
    [button.layer addSublayer:gradientLayer];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        gradientLayer.frame = button.bounds;
    });

}

- (void)didPressGotoNextPage:(id)sender {
    
    UITableView *table = [self.view viewWithTag:2222];
    
    [table setEditing:YES animated:YES];
//    NSMutableArray *arrViewcontrollers = self.navigationController.viewControllers.mutableCopy;
//    [arrViewcontrollers removeLastObject];
//    [arrViewcontrollers addObject:ThirdViewController.new];
//    [self.navigationController setViewControllers:arrViewcontrollers animated:YES];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
//    self.wcq_hideNavigationBarYesOrNo = NO;
}
- (void)didPressBackLastPage:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MyTestTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MyTestTableViewCell class]) forIndexPath:indexPath];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}



- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return  UITableViewCellEditingStyleInsert;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
  
}

- (void)willMoveToParentViewController:(UIViewController *)parent {
    [super willMoveToParentViewController:parent];
    NSLog(@"willMoveToParentViewController");
    
}
- (void)didMoveToParentViewController:(UIViewController *)parent {
    [super didMoveToParentViewController:parent];
    NSLog(@"didMoveToParentViewController");
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
