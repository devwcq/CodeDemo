//
//  ViewController.m
//  KevinWuDemo
//
//  Created by KevinWu on 2018/9/4.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import "ViewController.h"
#import "Masonry.h"
#import "SecondViewController.h"
#import "ForthViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"首页";
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"点我试试" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(didPressGotoNextPage:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(44);
        make.bottom.equalTo(self.view.mas_bottomMargin).offset(-20);
        make.left.right.equalTo(button.superview).insets(UIEdgeInsetsMake(0, 12, 0 , 12));
    }];

    CAGradientLayer *gradientLayer = [CAGradientLayer new];
    gradientLayer.colors = @[(id)[UIColor redColor].CGColor,(id)[UIColor greenColor].CGColor,(id)[UIColor blueColor].CGColor];
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(1, 0);
    [button.layer addSublayer:gradientLayer];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        gradientLayer.frame = button.bounds;
    });

    // Do any additional setup after loading the view, typically from a nib.
}


- (void)willMoveToParentViewController:(UIViewController *)parent {
    [super willMoveToParentViewController:parent];
    
}
- (void)didMoveToParentViewController:(UIViewController *)parent {
    [super didMoveToParentViewController:parent];
}

- (void)didPressGotoNextPage:(id)sender {
    [self.navigationController pushViewController:ForthViewController.new animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
