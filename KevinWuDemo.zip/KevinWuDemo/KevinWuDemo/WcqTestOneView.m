//
//  WcqTestOneView.m
//  KevinWuDemo
//
//  Created by KevinWu on 2018/9/6.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import "WcqTestOneView.h"

@implementation WcqTestOneView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    NSLog(@"Class = %@ hitPoint == %@", NSStringFromClass(self.class), NSStringFromCGPoint(point));
    return [super hitTest:point withEvent:event];
}
@end
