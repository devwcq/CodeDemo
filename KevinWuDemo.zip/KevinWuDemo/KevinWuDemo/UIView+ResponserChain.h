//
//  UIView+ResponserChain.h
//  KevinWuDemo
//
//  Created by KevinWu on 2018/9/6.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ResponserChain)

@end
