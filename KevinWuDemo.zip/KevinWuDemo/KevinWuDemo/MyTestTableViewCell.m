//
//  MyTestTableViewCell.m
//  KevinWuDemo
//
//  Created by KevinWu on 2018/10/18.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import "MyTestTableViewCell.h"

@implementation MyTestTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
