//
//  AppDelegate.h
//  KevinWuDemo
//
//  Created by KevinWu on 2018/9/4.
//  Copyright © 2018年 wcq. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "ViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

